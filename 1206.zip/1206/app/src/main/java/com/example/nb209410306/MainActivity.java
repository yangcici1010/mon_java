package com.example.nb209410306;
import androidx.appcompat.app.AppCompatActivity;

import android.opengl.Visibility;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener,
        CompoundButton.OnCheckedChangeListener {
    TextView rr; Button b1,b2 ; CheckBox c1,c2,c3,c4;
    RadioButton r1,r2,r3,r4,r5,r6,r7,r8,r9,r10,r11,r12;ArrayList<CompoundButton> sel=new ArrayList<CompoundButton>();
    ImageView im1,im2,im3,im4;
    int hh[]={100,90,80}, ff[]={60,50,40},cc[]={50,40,30},co[]={45,35,30};
    int hi=0,fi=0,cci=0,coi=0,money=0;String siz1[]={"大號","中號","小號"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rr=(TextView)findViewById((R.id.res));
        b1=(Button) findViewById((R.id.b1));
        b2=(Button) findViewById((R.id.b2));
        c1=(CheckBox)findViewById(R.id.chH);c2=(CheckBox)findViewById(R.id.chF);
        c3=(CheckBox)findViewById(R.id.chS);c4=(CheckBox)findViewById(R.id.chC);
        b1.setOnClickListener(this);b2.setOnClickListener(this);
        c1.setOnCheckedChangeListener(this);c2.setOnCheckedChangeListener(this);
        c3.setOnCheckedChangeListener(this);c4.setOnCheckedChangeListener(this);
        r1=(RadioButton)findViewById(R.id.rhb);r2=(RadioButton)findViewById(R.id.rhm);
        r3=(RadioButton)findViewById(R.id.rhs);r4=(RadioButton)findViewById(R.id.rfb);
        r5=(RadioButton)findViewById(R.id.rfm);r6=(RadioButton)findViewById(R.id.rfs);
        r7=(RadioButton)findViewById(R.id.rsb);r8=(RadioButton)findViewById(R.id.rsm);
        r9=(RadioButton)findViewById(R.id.rss);r10=(RadioButton)findViewById(R.id.rcb);
        r11=(RadioButton)findViewById(R.id.rcm);r12=(RadioButton)findViewById(R.id.rcs);
        im1=(ImageView)findViewById(R.id.imHH);im2=(ImageView)findViewById(R.id.imFF);
        im3=(ImageView)findViewById(R.id.imCOL);im4=(ImageView)findViewById(R.id.imCOR);

    }




    @Override
    public void onClick(View view) {
        if (view == b1) {

            String ss = ""; money=0;
            if (sel.size() > 0) {
                int i = 0;
                im1.setVisibility(View.GONE);im3.setVisibility(View.GONE);
                im2.setVisibility(View.GONE);im4.setVisibility(View.GONE);
                for (CompoundButton s1 : sel) {
                    if (i == 0) {
                        ss += s1.getText().toString();
                        i = 1;
                    } else ss += "、" + s1.getText().toString();
                    if (s1 == c1) { if (r1.isChecked()) hi = 0;else if (r2.isChecked()) hi = 1;else if (r3.isChecked()) hi = 2;
                        ss += siz1[hi];money += hh [ hi ] ; im1.setVisibility(View.VISIBLE);
                    }
                    if (s1 == c2) { if (r4.isChecked()) fi = 0;else if (r5.isChecked()) fi = 1;else if (r6.isChecked()) fi = 2;
                        ss += siz1[fi];money += ff [ fi ] ;im2.setVisibility(View.VISIBLE);
                    }
                    if (s1 == c3) { if (r7.isChecked()) cci = 0;else if (r8.isChecked()) cci = 1;else if (r9.isChecked()) cci = 2;
                        ss += siz1[cci];money += cc [ cci ] ;im3.setVisibility(View.VISIBLE);
                    }
                    if (s1 == c4) { if (r10.isChecked()) coi = 0;else if (r11.isChecked()) coi = 1;else if (r12.isChecked()) coi = 2;
                        ss += siz1[coi];money += co [ coi ] ;im4.setVisibility(View.VISIBLE);
                    }
                    rr.setText("點餐結果:" + ss+",應付"+money+"元");
                }
            } else rr.setText("請點餐!");
        }
        if (view == b2) {
            rr.setText("請點餐!");c1.setChecked(false); c2.setChecked(false);
            r7.setChecked(true);
            c3.setChecked(false);c4.setChecked(false);r1.setChecked(true);r4.setChecked(true);
            r10.setChecked(true);
            im1.setVisibility(View.GONE);im3.setVisibility(View.GONE);
            im2.setVisibility(View.GONE);im4.setVisibility(View.GONE);
        }

    }
    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
        if (b) sel.add(compoundButton); else sel.remove(compoundButton);
    }
}